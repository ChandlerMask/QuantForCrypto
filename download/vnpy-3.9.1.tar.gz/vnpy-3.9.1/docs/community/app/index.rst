策略应用
~~~~~~~~~

.. toctree::
   :maxdepth: 2
   :caption: Elite版

   cta_strategy.md
   cta_backtester.md
   spread_trading.md
   option_master.md
   portfolio_strategy.md   
   algo_trading.md
   script_trader.md
   paper_account.md
   data_recorder.md
   data_manager.md
   risk_manager.md
   rpc_service.md
   chart_wizard.md
   portfolio_manager.md
   excel_rtd.md
   web_trader.md
