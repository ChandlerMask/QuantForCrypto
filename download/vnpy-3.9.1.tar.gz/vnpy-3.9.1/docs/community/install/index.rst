安装指南
~~~~~~~~~

.. toctree::
   :maxdepth: 2

   windows_install.md
   ubuntu_install.md
   mac_install.md